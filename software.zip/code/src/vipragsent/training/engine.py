from __future__ import annotations

import json
import os
import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor, nn

from ..atomic import atomic_write_json
from ..constants import EMOTION_LABELS, POLARITY_LABELS, PRAGMATIC_LABELS
from ..data.sampling import DeterministicSampler
from ..evaluation.metrics import binary_macro_f1, macro_pragmatic_f1, multiclass_macro_f1
from ..evaluation.thresholds import tune_binary_threshold
from ..models.losses import (
    UncertaintyWeightedMultiTaskLoss,
    classification_losses,
    equal_weight_loss,
    token_cross_entropy,
)
from ..orchestration.status import RuntimeBlocked
from ..runtime.device import (
    assert_runtime_device_contract,
    move_batch_to_model_device,
    resolve_model_input_device,
    resolve_selected_cuda_device,
    tensor_devices,
    write_device_report,
)
from .checkpoints import (
    build_checkpoint_payload,
    infer_required_head_prefixes,
    load_checkpoint,
    save_checkpoint,
)
from .class_weights import ClassWeightBundle
from .config_resolver import ResolvedTrainingConfig
from .optimizers import build_optimizer
from .schedulers import build_scheduler
from .seeding import seed_everything


@dataclass(frozen=True)
class TrainingConfig:
    learning_rate: float = 2e-5
    weight_decay: float = 0.01
    max_epochs: int = 1
    effective_batch_size: int = 32
    physical_batch_size: int = 2
    max_grad_norm: float = 1.0
    patience: int = 2
    min_delta: float = 0.0001
    precision: str = "bf16"
    gradient_accumulation_steps: int = 1
    primary_metric: str = "dev_macro_pragmatic_f1"
    scheduler: str = "linear"
    warmup_ratio: float = 0.1
    use_uncertainty_weighting: bool = True
    rationale_beta: float = 0.3
    rationale_target_max_length: int = 160
    optimizer: str = "AdamW"
    gradient_checkpointing: bool = False
    deterministic_algorithms: str = "warn_only"
    qlora: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_resolved(cls, resolved: ResolvedTrainingConfig) -> TrainingConfig:
        return cls(
            learning_rate=resolved.learning_rate,
            weight_decay=resolved.weight_decay,
            max_epochs=resolved.maximum_epochs,
            effective_batch_size=resolved.effective_batch_size,
            physical_batch_size=resolved.physical_batch_size,
            max_grad_norm=resolved.gradient_clipping,
            patience=resolved.patience,
            min_delta=resolved.minimum_delta,
            precision=resolved.precision,
            gradient_accumulation_steps=resolved.gradient_accumulation_steps,
            primary_metric=resolved.selection_metric,
            scheduler=resolved.scheduler,
            warmup_ratio=resolved.warmup_ratio,
            use_uncertainty_weighting=resolved.uncertainty_weighting_enabled,
            rationale_beta=resolved.rationale_beta,
            rationale_target_max_length=resolved.rationale_target_max_length,
            optimizer=resolved.optimizer,
            gradient_checkpointing=resolved.gradient_checkpointing,
            deterministic_algorithms=resolved.deterministic_algorithms,
            qlora=dict(resolved.qlora),
        )

    def __post_init__(self) -> None:
        if self.precision not in {"fp32", "bf16", "fp16"}:
            raise ValueError(f"Unsupported precision: {self.precision}")
        if self.gradient_accumulation_steps < 1 or self.max_epochs < 1:
            raise ValueError("max_epochs and gradient_accumulation_steps must be positive")
        if self.primary_metric not in {
            "dev_macro_pragmatic_f1",
            "dev_sarcasm_macro_f1",
            "dev_sarcasm_binary_macro_f1",
            "dev_polarity_macro_f1",
            "dev_emotion_macro_f1",
        }:
            raise ValueError(f"Unsupported primary metric: {self.primary_metric}")


@dataclass
class RunState:
    epoch: int = 0
    best_metric: float = float("-inf")
    best_loss: float = float("inf")
    best_epoch: int | None = None
    no_improvement_epochs: int = 0
    optimizer_updates: int = 0
    micro_batches: int = 0
    status: str = "PENDING"
    thresholds: dict[str, float] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class SelectionResult:
    metric: float
    total_loss: float
    thresholds: dict[str, float] = field(default_factory=dict)
    true: dict[str, list[Any]] = field(default_factory=dict)
    probabilities: dict[str, Any] = field(default_factory=dict)
    predictions: dict[str, list[Any]] = field(default_factory=dict)
    logits: dict[str, list[Any]] = field(default_factory=dict)


SelectionCallback = Callable[["TrainingEngine", list[dict[str, Any]]], SelectionResult]


class CheckpointManager:
    def __init__(self, root: str | Path, run_id: str, *, allow_legacy_fixture: bool = False) -> None:
        self.path = Path(root) / run_id
        self.path.mkdir(parents=True, exist_ok=True)
        self.allow_legacy_fixture = allow_legacy_fixture

    def _payload(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any,
        loss_aggregator: nn.Module,
        state: RunState,
    ) -> dict[str, Any]:
        return build_checkpoint_payload(
            model,
            optimizer,
            scheduler,
            loss_aggregator,
            asdict(state),
            metadata={"producer": "TrainingEngine", "run_id": self.path.name},
        )

    def save(
        self,
        name: str,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any,
        loss_aggregator: nn.Module,
        state: RunState,
    ) -> Path:
        path = self.path / f"{name}.pt"
        save_checkpoint(path, self._payload(model, optimizer, scheduler, loss_aggregator, state))
        return path

    def _load_payload(
        self,
        path: Path,
        model: nn.Module,
        optimizer: torch.optim.Optimizer | None,
        scheduler: Any,
        loss_aggregator: nn.Module,
        *,
        restore_training_state: bool,
        allow_legacy_fixture: bool | None = None,
    ) -> RunState:
        result = load_checkpoint(
            path,
            model,
            optimizer=optimizer,
            scheduler=scheduler,
            loss_aggregator=loss_aggregator,
            restore_training_state=restore_training_state,
            allow_legacy_fixture=self.allow_legacy_fixture if allow_legacy_fixture is None else allow_legacy_fixture,
            required_head_prefixes=infer_required_head_prefixes(model),
            report_path=self.path / "load_reports" / f"{path.stem}.json",
        )
        state = dict(result.run_state)
        fields = RunState.__dataclass_fields__
        return RunState(**{name: state[name] for name in fields if name in state})

    def load_latest(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any,
        loss_aggregator: nn.Module,
        *,
        allow_legacy_fixture: bool | None = None,
    ) -> RunState | None:
        checkpoints = sorted(self.path.glob("epoch_*.pt"))
        if not checkpoints:
            return None
        return self._load_payload(checkpoints[-1], model, optimizer, scheduler, loss_aggregator, restore_training_state=True, allow_legacy_fixture=allow_legacy_fixture)

    def load_best(self, model: nn.Module, loss_aggregator: nn.Module, *, allow_legacy_fixture: bool | None = None) -> RunState | None:
        path = self.path / "best.pt"
        if not path.exists():
            return None
        return self._load_payload(path, model, None, None, loss_aggregator, restore_training_state=False, allow_legacy_fixture=allow_legacy_fixture)


class EvaluationAccessGate:
    def __init__(self) -> None:
        self.checkpoint_frozen = False

    def freeze_checkpoint(self) -> None:
        self.checkpoint_frozen = True

    def assert_test_allowed(self) -> None:
        if not self.checkpoint_frozen:
            raise RuntimeError("Test evaluation is prohibited before checkpoint selection is frozen")


def _active_pragmatic_keys(logits: Mapping[str, Tensor]) -> tuple[str, ...]:
    return tuple(key for key in PRAGMATIC_LABELS if key in logits)


class TrainingEngine:
    def __init__(
        self,
        model: nn.Module,
        config: TrainingConfig,
        *,
        run_id: str,
        checkpoint_root: str | Path = "checkpoints",
        runtime_hooks: Mapping[str, Callable[..., Any]] | None = None,
        class_weights: ClassWeightBundle | Mapping[str, Any] | None = None,
        resolved_config: Mapping[str, Any] | None = None,
        optimizer_module: Any | None = None,
        selected_device: torch.device | str | int | None = None,
        executor_kind: str | None = None,
        loss_multipliers: Mapping[str, float] | None = None,
        gradient_strategy: str = "sum",
        batch_order: str = "fixed",
    ) -> None:
        if executor_kind in {"single_task_bundle", "independent_checkpoint_bundle", "component_bundle"}:
            raise RuntimeBlocked("bundle executor kinds must not be passed to the generic TrainingEngine")
        self.model = model
        self.config = config
        self.run_id = run_id
        self.device = (
            resolve_selected_cuda_device(selected_device)
            if selected_device is not None
            else resolve_model_input_device(model)
        )
        self.model_family = str((resolved_config or {}).get("model_family", getattr(model, "_vipragsent_model_family", "unknown")))
        self.quantized = bool(getattr(model, "_vipragsent_quantized", False) or getattr(getattr(model, "backbone", None), "_vipragsent_quantized", False))
        self.runtime_hooks = dict(runtime_hooks or {})
        self.loss_multipliers = {
            str(key): float(value)
            for key, value in (loss_multipliers or {}).items()
        }
        if any(value <= 0.0 for value in self.loss_multipliers.values()):
            raise ValueError("loss multipliers must be positive")
        self.gradient_strategy = str(gradient_strategy)
        if self.gradient_strategy not in {"sum", "pcgrad_sarcasm_irony", "pcgrad_shared_sarcasm_irony"}:
            raise ValueError(f"Unsupported gradient strategy: {self.gradient_strategy}")
        self.gradient_focus_tasks = (
            ("sarcasm", "irony")
            if self.gradient_strategy in {"pcgrad_sarcasm_irony", "pcgrad_shared_sarcasm_irony"}
            else ()
        )
        if self.gradient_strategy == "pcgrad_shared_sarcasm_irony":
            setattr(model, "_vipragsent_expose_shared_representation", True)
        self._last_shared_representation: Tensor | None = None
        self.batch_order = str(batch_order)
        if self.batch_order not in {"fixed", "deterministic_batch_shuffle"}:
            raise ValueError(f"Unsupported batch order: {self.batch_order}")
        variant_config = getattr(model, "config", None)
        variant_uncertainty = bool(getattr(variant_config, "has_uncertainty_weighting", True))
        self.uses_uncertainty_weighting = bool(config.use_uncertainty_weighting and variant_uncertainty)
        uncertainty_tasks = getattr(variant_config, "uncertainty_task_keys", None) or (*PRAGMATIC_LABELS, "polarity", "emotion")
        self.loss_aggregator = UncertaintyWeightedMultiTaskLoss(config.rationale_beta, tasks=uncertainty_tasks) if self.uses_uncertainty_weighting else nn.Identity()
        try:
            device = next(model.parameters()).device
            self.loss_aggregator.to(device)
        except StopIteration:
            pass

        self.optimizer, self.optimizer_summary = build_optimizer(
            model,
            optimizer_name=config.optimizer,
            learning_rate=config.learning_rate,
            weight_decay=config.weight_decay,
            uncertainty_parameters=self.loss_aggregator.parameters() if self.uses_uncertainty_weighting else (),
            optimizer_module=optimizer_module,
        )
        self.class_weights = class_weights.as_dict() if isinstance(class_weights, ClassWeightBundle) else dict(class_weights or {})
        self.resolved_config = dict(resolved_config or {})
        self.checkpoints = CheckpointManager(checkpoint_root, run_id)
        self.gate = EvaluationAccessGate()
        self.scheduler: Any = None
        self._scheduler_total_steps = 0
        self.device_report_path = Path(checkpoint_root).parent / "training/device_report.json"
        self._device_report_written = False

    def _ensure_scheduler(self, total_steps: int) -> None:
        if self.scheduler is not None and self._scheduler_total_steps == total_steps:
            return
        self.scheduler, self.scheduler_summary = build_scheduler(
            self.optimizer,
            scheduler_name=self.config.scheduler,
            warmup_ratio=self.config.warmup_ratio,
            total_steps=total_steps,
        )
        self.scheduler_summary.update({"steps_per_epoch": total_steps // max(self.config.max_epochs, 1), "gradient_accumulation_steps": self.config.gradient_accumulation_steps, "epochs": self.config.max_epochs})
        self._scheduler_total_steps = total_steps

    def _autocast(self) -> Any:
        if self.config.precision not in {"bf16", "fp16"} or not torch.cuda.is_available():
            return torch.autocast(device_type="cpu", enabled=False)
        dtype = torch.bfloat16 if self.config.precision == "bf16" else torch.float16
        return torch.autocast(device_type="cuda", dtype=dtype)

    def _prepare_batch(self, batch: dict[str, Any]) -> dict[str, Any]:
        return move_batch_to_model_device(batch, self.model, device=self.device)

    def _write_first_step_device_report(self, batch: Mapping[str, Any], loss: Tensor) -> None:
        if self._device_report_written:
            return
        try:
            report = assert_runtime_device_contract(
                self.model,
                self.device,
                model_family=self.model_family,
                quantized=self.quantized,
                device_map=getattr(getattr(self.model, "backbone", self.model), "_vipragsent_qlora_contract", {}).get("device_map"),
                batch=batch,
                loss=loss,
                uncertainty_module=self.loss_aggregator if self.uses_uncertainty_weighting else None,
                require_lora=self.quantized,
            )
        except RuntimeBlocked as exc:
            report = {
                "selected_device": str(self.device),
                "device_index": self.device.index,
                "device_name": "cpu" if self.device.type == "cpu" else "unresolved",
                "compute_capability": "n/a",
                "model_family": self.model_family,
                "quantized": self.quantized,
                "device_map": {},
                "backbone_devices": sorted({str(parameter.device) for name, parameter in self.model.named_parameters() if name.startswith("backbone.")}),
                "trainable_parameter_devices": sorted({str(parameter.device) for parameter in self.model.parameters() if parameter.requires_grad}),
                "frozen_parameter_devices": sorted({str(parameter.device) for parameter in self.model.parameters() if not parameter.requires_grad}),
                "head_devices": [],
                "rationale_device": [],
                "uncertainty_device": [],
                "first_batch_tensor_devices": sorted({str(device) for device in tensor_devices(batch)}),
                "loss_device": str(loss.device),
                "status": "BLOCKED",
                "blockers": [str(exc)],
            }
            write_device_report(self.device_report_path, report)
            raise
        write_device_report(self.device_report_path, report)
        self._device_report_written = True

    def _loss(self, batch: dict[str, Any]) -> tuple[Tensor, dict[str, Tensor]]:
        batch = self._prepare_batch(batch)
        pragmatic_weights = dict(self.class_weights.get("pragmatic_pos_weight", {}) or {})
        pragmatic_weights.update(dict(batch.get("pragmatic_pos_weight") or {}))
        polarity_weight = self.class_weights.get("polarity_weight", batch.get("polarity_weight"))
        emotion_weight = self.class_weights.get("emotion_weight", batch.get("emotion_weight"))
        if polarity_weight is not None and not isinstance(polarity_weight, Tensor):
            polarity_weight = torch.tensor([float(polarity_weight[label]) for label in POLARITY_LABELS], dtype=torch.float32)
        if emotion_weight is not None and not isinstance(emotion_weight, Tensor):
            emotion_weight = torch.tensor([float(emotion_weight[label]) for label in EMOTION_LABELS], dtype=torch.float32)
        if isinstance(polarity_weight, Tensor):
            polarity_weight = polarity_weight.to(batch["input_ids"].device)
        if isinstance(emotion_weight, Tensor):
            emotion_weight = emotion_weight.to(batch["input_ids"].device)
        with self._autocast():
            output = self.model(
                batch["input_ids"],
                batch["attention_mask"],
                rationale_input_ids=batch.get("rationale_input_ids"),
                rationale_attention_mask=batch.get("rationale_attention_mask"),
            )
            self._last_shared_representation = output.get("_shared_representation")
            losses = classification_losses(
                output["logits"],
                batch["targets"],
                pragmatic_pos_weight=pragmatic_weights or None,
                polarity_weight=polarity_weight,
                emotion_weight=emotion_weight,
                active_tasks=self.model.config.active_tasks,
                target_masks=batch.get("target_masks"),
                sarcasm_target_mask=batch.get("sarcasm_target_mask"),
            )
            if self.loss_multipliers:
                losses = {
                    key: loss * self.loss_multipliers.get(key, 1.0)
                    for key, loss in losses.items()
                }
            rationale_loss = None
            if "rationale_logits" in output:
                rationale_targets = output.get("rationale_labels", batch.get("rationale_targets"))
                if rationale_targets is not None:
                    rationale_loss = token_cross_entropy(
                        output["rationale_logits"],
                        rationale_targets,
                        sample_mask=batch.get("rationale_loss_mask"),
                    )
            if self.uses_uncertainty_weighting:
                return self.loss_aggregator(losses, rationale_loss)
            reference = next(self.model.parameters(), None)
            return equal_weight_loss(losses, rationale_loss, rationale_beta=self.config.rationale_beta, reference=reference)

    @staticmethod
    def _pcgrad_combine(
        gradients: list[tuple[Tensor | None, ...]],
    ) -> tuple[Tensor | None, ...]:
        """Project conflicting task gradients with a deterministic task order."""
        if not gradients:
            return ()
        projected = [
            [gradient.detach().clone() if gradient is not None else None for gradient in task_gradients]
            for task_gradients in gradients
        ]
        for index, current in enumerate(projected):
            for other_index, other in enumerate(gradients):
                if index == other_index:
                    continue
                dot: Tensor | None = None
                norm: Tensor | None = None
                for current_gradient, other_gradient in zip(current, other):
                    if current_gradient is None or other_gradient is None:
                        continue
                    contribution = (current_gradient * other_gradient).sum()
                    dot = contribution if dot is None else dot + contribution
                    other_norm = (other_gradient * other_gradient).sum()
                    norm = other_norm if norm is None else norm + other_norm
                if dot is None or norm is None or float(dot.detach().cpu()) >= 0.0:
                    continue
                scale = dot / norm.clamp_min(torch.finfo(dot.dtype).eps)
                for parameter_index, (current_gradient, other_gradient) in enumerate(zip(current, other)):
                    if current_gradient is not None and other_gradient is not None:
                        current[parameter_index] = current_gradient - scale * other_gradient
        combined: list[Tensor | None] = []
        for parameter_index in range(len(projected[0])):
            values = [task[parameter_index] for task in projected if task[parameter_index] is not None]
            combined.append(torch.stack(values, dim=0).sum(dim=0) if values else None)
        return tuple(combined)

    @staticmethod
    def _accumulate_gradients(
        parameters: list[nn.Parameter],
        gradients: tuple[Tensor | None, ...],
    ) -> None:
        for parameter, gradient in zip(parameters, gradients):
            if gradient is None:
                continue
            detached = gradient.detach()
            if parameter.grad is None:
                parameter.grad = detached.clone()
            else:
                parameter.grad.add_(detached)

    def _backward(self, total: Tensor, components: Mapping[str, Tensor], *, normalization: int) -> None:
        scaled_total = total / normalization
        if self.gradient_strategy == "sum":
            scaled_total.backward()
            return
        if self.gradient_strategy == "pcgrad_shared_sarcasm_irony":
            self._backward_shared_representation(scaled_total, components, normalization=normalization)
            return

        model_parameters = [parameter for parameter in self.model.parameters() if parameter.requires_grad]
        if not model_parameters:
            raise RuntimeError("PCGrad requires trainable model parameters")
        focus = tuple(key for key in self.gradient_focus_tasks if key in components)
        rest_components = [loss for key, loss in components.items() if key not in focus]
        if not focus or not rest_components:
            scaled_total.backward()
            return
        rest_loss = sum((loss / normalization for loss in rest_components), scaled_total.new_zeros(()))
        task_losses = [rest_loss] + [components[key] / normalization for key in focus]
        task_gradients = [
            torch.autograd.grad(
                loss,
                model_parameters,
                retain_graph=True,
                allow_unused=True,
            )
            for loss in task_losses
        ]
        combined = self._pcgrad_combine(task_gradients)
        self._accumulate_gradients(model_parameters, combined)

        aggregator_parameters = [parameter for parameter in self.loss_aggregator.parameters() if parameter.requires_grad]
        if aggregator_parameters:
            aggregator_gradients = torch.autograd.grad(
                scaled_total,
                aggregator_parameters,
                retain_graph=False,
                allow_unused=True,
            )
            self._accumulate_gradients(aggregator_parameters, aggregator_gradients)

    def _backward_shared_representation(
        self,
        scaled_total: Tensor,
        components: Mapping[str, Tensor],
        *,
        normalization: int,
    ) -> None:
        shared = self._last_shared_representation
        if shared is None or not shared.requires_grad:
            scaled_total.backward()
            return
        focus = tuple(key for key in self.gradient_focus_tasks if key in components)
        rest_components = [loss for key, loss in components.items() if key not in focus]
        if not focus or not rest_components:
            scaled_total.backward()
            return
        rest_loss = sum((loss / normalization for loss in rest_components), scaled_total.new_zeros(()))
        task_losses = [rest_loss] + [components[key] / normalization for key in focus]
        shared_gradients = [
            torch.autograd.grad(
                loss,
                shared,
                retain_graph=True,
                allow_unused=True,
            )[0]
            for loss in task_losses
        ]
        combined = self._pcgrad_combine([(gradient,) for gradient in shared_gradients])[0]
        if combined is None:
            scaled_total.backward()
            return

        named_parameters = [(name, parameter) for name, parameter in self.model.named_parameters() if parameter.requires_grad]
        non_shared_parameters = [parameter for name, parameter in named_parameters if not name.startswith("backbone.")]
        if non_shared_parameters:
            non_shared_gradients = torch.autograd.grad(
                scaled_total,
                non_shared_parameters,
                retain_graph=True,
                allow_unused=True,
            )
            self._accumulate_gradients(non_shared_parameters, non_shared_gradients)
        aggregator_parameters = [parameter for parameter in self.loss_aggregator.parameters() if parameter.requires_grad]
        if aggregator_parameters:
            aggregator_gradients = torch.autograd.grad(
                scaled_total,
                aggregator_parameters,
                retain_graph=True,
                allow_unused=True,
            )
            self._accumulate_gradients(aggregator_parameters, aggregator_gradients)
        torch.autograd.backward(shared, grad_tensors=combined, retain_graph=False)

    def _epoch_batches(self, batches: list[dict[str, Any]], *, seed: int, epoch: int) -> list[dict[str, Any]]:
        if self.batch_order == "fixed":
            return batches
        return list(DeterministicSampler(batches, seed=seed, epoch=epoch))

    def _default_selection(self, batches: list[dict[str, Any]], *, thresholds_override: Mapping[str, float] | None = None) -> SelectionResult:
        self.model.eval()
        true_prag = {key: [] for key in PRAGMATIC_LABELS}
        prob_prag = {key: [] for key in PRAGMATIC_LABELS}
        true_polarity: list[int] = []
        prob_polarity: list[list[float]] = []
        true_emotion: list[int] = []
        prob_emotion: list[list[float]] = []
        logits_export: dict[str, list[Any]] = {}
        losses: list[float] = []
        with torch.no_grad():
            for batch in batches:
                prepared_batch = self._prepare_batch(batch)
                total, _ = self._loss(prepared_batch)
                losses.append(float(total.detach().cpu()))
                output = self.model(prepared_batch["input_ids"], prepared_batch["attention_mask"])
                logits = output.get("logits", {})
                for key in _active_pragmatic_keys(logits):
                    values = logits[key].detach().cpu()
                    logits_export.setdefault(key, []).extend(values.tolist())
                    prob_prag[key].extend(torch.sigmoid(values).tolist())
                    true_prag[key].extend(prepared_batch["targets"][key].detach().cpu().int().tolist())
                if "polarity" in logits:
                    values = logits["polarity"].detach().cpu()
                    logits_export.setdefault("polarity", []).extend(values.tolist())
                    prob_polarity.extend(torch.softmax(values, dim=-1).tolist())
                    true_polarity.extend(prepared_batch["targets"]["polarity"].detach().cpu().int().tolist())
                if "emotion" in logits:
                    values = logits["emotion"].detach().cpu()
                    logits_export.setdefault("emotion", []).extend(values.tolist())
                    prob_emotion.extend(torch.softmax(values, dim=-1).tolist())
                    true_emotion.extend(prepared_batch["targets"]["emotion"].detach().cpu().int().tolist())

        thresholds: dict[str, float] = {}
        predictions: dict[str, list[Any]] = {}
        primary = self.config.primary_metric
        active_prag = _active_pragmatic_keys({key: torch.empty(0) for key in prob_prag if prob_prag[key]})
        if active_prag:
            pragmatic_true = {key: true_prag[key] for key in active_prag}
            pragmatic_prob = {key: prob_prag[key] for key in active_prag}
            thresholds = dict(thresholds_override or {key: tune_binary_threshold(pragmatic_true[key], pragmatic_prob[key]) for key in active_prag})
            missing_thresholds = [key for key in active_prag if key not in thresholds]
            if missing_thresholds:
                raise ValueError(f"Frozen threshold set is missing pragmatic labels: {missing_thresholds}")
            predictions.update({key: [int(value >= thresholds[key]) for value in pragmatic_prob[key]] for key in active_prag})
        if primary in {"dev_sarcasm_macro_f1", "dev_sarcasm_binary_macro_f1"}:
            if "sarcasm" not in predictions:
                raise ValueError("Q3 selection requires sarcasm logits on the dev set")
            metric = binary_macro_f1(true_prag["sarcasm"], predictions["sarcasm"])
        elif primary == "dev_polarity_macro_f1":
            if not prob_polarity:
                raise ValueError("Polarity selection requires polarity logits on the dev set")
            predictions["polarity"] = np.asarray(prob_polarity).argmax(axis=1).tolist()
            metric = multiclass_macro_f1(true_polarity, predictions["polarity"], range(len(POLARITY_LABELS)))
        elif primary == "dev_emotion_macro_f1":
            if not prob_emotion:
                raise ValueError("Emotion selection requires emotion logits on the dev set")
            predictions["emotion"] = np.asarray(prob_emotion).argmax(axis=1).tolist()
            metric = multiclass_macro_f1(true_emotion, predictions["emotion"], range(len(EMOTION_LABELS)))
        elif active_prag == PRAGMATIC_LABELS:
            metric = macro_pragmatic_f1(true_prag, {key: predictions[key] for key in PRAGMATIC_LABELS})
        elif all(key in true_prag and true_prag[key] for key in active_prag):
            metric = float(np.mean([binary_macro_f1(true_prag[key], predictions[key]) for key in active_prag]))
        else:
            raise ValueError("The default dev selector has no supported task outputs; provide a selection callback")
        true: dict[str, list[Any]] = {key: values for key, values in true_prag.items() if values}
        probabilities: dict[str, Any] = {key: values for key, values in prob_prag.items() if values}
        if true_polarity:
            true["polarity"] = true_polarity
            probabilities["polarity"] = prob_polarity
        if true_emotion:
            true["emotion"] = true_emotion
            probabilities["emotion"] = prob_emotion
        return SelectionResult(float(metric), float(np.mean(losses) if losses else 0.0), thresholds, true, probabilities, predictions, logits_export)

    def _evaluate_dev(
        self,
        batches: list[dict[str, Any]],
        selection_callback: SelectionCallback | None = None,
        *,
        thresholds_override: Mapping[str, float] | None = None,
    ) -> SelectionResult:
        if selection_callback:
            if thresholds_override:
                raise ValueError("Custom selection callbacks cannot retune or override frozen thresholds")
            return selection_callback(self, batches)
        return self._default_selection(batches, thresholds_override=thresholds_override)

    @staticmethod
    def _prediction_rows(selection: SelectionResult, *, sample_ids: list[str] | None = None) -> list[dict[str, Any]]:
        count = max((len(values) for values in selection.predictions.values()), default=0)
        rows: list[dict[str, Any]] = []
        for index in range(count):
            row: dict[str, Any] = {"sample_id": sample_ids[index] if sample_ids and index < len(sample_ids) else f"row_{index:06d}"}
            row["predictions"] = {key: values[index] for key, values in selection.predictions.items() if index < len(values)}
            row["gold"] = {key: values[index] for key, values in selection.true.items() if index < len(values)}
            row["probabilities"] = {
                key: values[index] for key, values in selection.probabilities.items() if index < len(values)
            }
            row["logits"] = {key: values[index] for key, values in selection.logits.items() if index < len(values)}
            rows.append(row)
        return rows

    def _write_prediction_jsonl(self, path: Path, rows: list[dict[str, Any]]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)

    def _export_run_outputs(
        self,
        state: RunState,
        dev_selection: SelectionResult,
        *,
        dev_batches: list[dict[str, Any]],
        test_batches: list[dict[str, Any]] | None,
        output_root: Path,
        metadata: Mapping[str, Any] | None,
        selection_callback: SelectionCallback | None,
    ) -> None:
        output_root.mkdir(parents=True, exist_ok=True)
        dev_ids = [sample_id for batch in dev_batches for sample_id in batch.get("sample_ids", [])]
        self._write_prediction_jsonl(output_root / "dev_predictions.jsonl", self._prediction_rows(dev_selection, sample_ids=dev_ids))
        test_selection = None
        if test_batches is not None:
            self.gate.assert_test_allowed()
            test_selection = self._evaluate_dev(test_batches, selection_callback, thresholds_override=state.thresholds)
            test_ids = [sample_id for batch in test_batches for sample_id in batch.get("sample_ids", [])]
            self._write_prediction_jsonl(output_root / "test_predictions.jsonl", self._prediction_rows(test_selection, sample_ids=test_ids))
        atomic_write_json(output_root / "thresholds.json", state.thresholds)
        atomic_write_json(output_root / "training_history.json", state.history)
        atomic_write_json(
            output_root / "run_manifest.json",
            {
                "run_id": self.run_id,
                "status": state.status,
                "best_metric": state.best_metric,
                "best_epoch": state.best_epoch,
                "primary_metric": self.config.primary_metric,
                "thresholds_frozen": bool(self.gate.checkpoint_frozen),
                "dev_metric": dev_selection.metric,
                "test_metric": test_selection.metric if test_selection else None,
                "prediction_files": [name for name, enabled in (("dev_predictions.jsonl", True), ("test_predictions.jsonl", test_selection is not None)) if enabled],
                "precision_requested": self.config.precision,
                "precision_runtime": self.config.precision if torch.cuda.is_available() else "fp32_cpu_fallback",
                "optimizer": self.optimizer_summary,
                "scheduler": getattr(self, "scheduler_summary", {}),
                "resolved_training_config": self.resolved_config,
                **dict(metadata or {}),
            },
        )
        atomic_write_json(output_root.parent / "training/optimizer_summary.json", self.optimizer_summary)
        atomic_write_json(output_root.parent / "training/scheduler_summary.json", getattr(self, "scheduler_summary", {}))

    def train(
        self,
        batches: Iterable[dict[str, Any]],
        *,
        seed: int,
        dev_batches: Iterable[dict[str, Any]] | None = None,
        test_batches: Iterable[dict[str, Any]] | None = None,
        resume: bool = False,
        selection_callback: SelectionCallback | None = None,
        output_root: str | Path | None = None,
        run_metadata: Mapping[str, Any] | None = None,
    ) -> RunState:
        seed_everything(seed)
        batches_list = list(batches)
        if not batches_list:
            raise ValueError("Training requires at least one batch")
        dev_list = list(dev_batches or batches_list)
        test_list = list(test_batches) if test_batches is not None else None
        updates_per_epoch = (len(batches_list) + self.config.gradient_accumulation_steps - 1) // self.config.gradient_accumulation_steps
        self._ensure_scheduler(updates_per_epoch * self.config.max_epochs)
        state = self.checkpoints.load_latest(self.model, self.optimizer, self.scheduler, self.loss_aggregator) if resume else None
        state = state or RunState(status="RUNNING")
        for epoch in range(state.epoch, self.config.max_epochs):
            self.model.train()
            started = time.perf_counter()
            if hook := self.runtime_hooks.get("on_epoch_start"):
                hook(epoch + 1, state)
            train_losses: list[float] = []
            self.optimizer.zero_grad(set_to_none=True)
            epoch_batches = self._epoch_batches(batches_list, seed=seed, epoch=epoch)
            for start in range(0, len(epoch_batches), self.config.gradient_accumulation_steps):
                window = epoch_batches[start:start + self.config.gradient_accumulation_steps]
                window_loss = 0.0
                for batch in window:
                    prepared_batch = self._prepare_batch(batch)
                    total, components = self._loss(prepared_batch)
                    self._write_first_step_device_report(prepared_batch, total)
                    self._backward(total, components, normalization=len(window))
                    window_loss += float(total.detach().cpu())
                    state.micro_batches += 1
                optimizer_parameters = list(self.model.parameters()) + (list(self.loss_aggregator.parameters()) if self.uses_uncertainty_weighting else [])
                nn.utils.clip_grad_norm_(optimizer_parameters, self.config.max_grad_norm)
                self.optimizer.step()
                if self.scheduler is not None:
                    self.scheduler.step()
                self.optimizer.zero_grad(set_to_none=True)
                state.optimizer_updates += 1
                train_losses.append(window_loss / len(window))
                if hook := self.runtime_hooks.get("on_optimizer_step"):
                    hook(state.optimizer_updates, state)
            dev_selection = self._evaluate_dev(dev_list, selection_callback)
            pragmatic_metric = (
                macro_pragmatic_f1(
                    {key: dev_selection.true[key] for key in PRAGMATIC_LABELS},
                    {key: dev_selection.predictions[key] for key in PRAGMATIC_LABELS},
                )
                if all(key in dev_selection.true and key in dev_selection.predictions for key in PRAGMATIC_LABELS)
                else None
            )
            record = {
                "epoch": float(epoch + 1),
                "train_loss": float(np.mean(train_losses)),
                "dev_loss": dev_selection.total_loss,
                "dev_metric": dev_selection.metric,
                "dev_macro_pragmatic_f1": pragmatic_metric,
                "seconds": time.perf_counter() - started,
            }
            if torch.cuda.is_available():
                record["peak_memory_gb"] = float(torch.cuda.max_memory_allocated() / (1024**3))
                torch.cuda.reset_peak_memory_stats()
            state.history.append(record)
            state.epoch = epoch + 1
            state.thresholds = dev_selection.thresholds
            improved = dev_selection.metric > state.best_metric + self.config.min_delta or (
                abs(dev_selection.metric - state.best_metric) <= self.config.min_delta and dev_selection.total_loss < state.best_loss
            )
            if improved:
                state.best_metric = dev_selection.metric
                state.best_loss = dev_selection.total_loss
                state.best_epoch = epoch + 1
                state.no_improvement_epochs = 0
                self.checkpoints.save("best", self.model, self.optimizer, self.scheduler, self.loss_aggregator, state)
            else:
                state.no_improvement_epochs += 1
            self.checkpoints.save(f"epoch_{epoch + 1:03d}", self.model, self.optimizer, self.scheduler, self.loss_aggregator, state)
            if hook := self.runtime_hooks.get("on_epoch_end"):
                hook(epoch + 1, state, dev_selection)
            if state.no_improvement_epochs >= self.config.patience:
                break
        state.status = "PASS"
        best_state = self.checkpoints.load_best(self.model, self.loss_aggregator)
        if best_state is not None:
            state.best_metric = best_state.best_metric
            state.best_loss = best_state.best_loss
            state.best_epoch = best_state.best_epoch
            state.thresholds = best_state.thresholds
        atomic_write_json(self.checkpoints.path / "run_state.json", asdict(state))
        atomic_write_json(self.checkpoints.path / "thresholds.json", state.thresholds)
        self.gate.freeze_checkpoint()
        final_selection = self._evaluate_dev(dev_list, selection_callback, thresholds_override=state.thresholds)
        self._export_run_outputs(
            state,
            final_selection,
            dev_batches=dev_list,
            test_batches=test_list,
            output_root=Path(output_root) if output_root else self.checkpoints.path,
            metadata={"seed": seed, **dict(run_metadata or {})},
            selection_callback=selection_callback,
        )
        return state

    def assert_test_access(self) -> None:
        self.gate.assert_test_allowed()
